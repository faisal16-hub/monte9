
  # monte test 1

  This is a code bundle for monte test 1. The original project is available at https://www.figma.com/design/mSd28TbpB8ivxRcr8FzuEh/monte-test-1.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  